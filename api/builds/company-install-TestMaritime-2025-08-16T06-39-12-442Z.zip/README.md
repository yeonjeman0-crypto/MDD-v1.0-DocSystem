# MDD Company Installation Package

Company: Test Maritime
License Key: LICENSE-123
Admin Email: admin@test.com

## Installation Instructions
1. Install PostgreSQL 13+ 
2. Run database/setup.sql
3. Run install.bat as Administrator
4. Access admin portal at http://localhost:5177

## System Requirements
- Windows Server 2019 or later
- PostgreSQL 13+
- 8GB RAM minimum
- 10GB free disk space
- Firewall ports: 3005 (API), 5177 (Admin)

## Post-Installation
1. Login to admin portal with admin email
2. Configure ship connections
3. Upload initial document packages
4. Create user accounts

## Support
Email: support@mdd-system.com
Phone: +1-555-MDD-HELP
