-- MDD PostgreSQL Database Setup
CREATE DATABASE mdd_v1_production;
CREATE USER mdd_user WITH ENCRYPTED PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE mdd_v1_production TO mdd_user;
