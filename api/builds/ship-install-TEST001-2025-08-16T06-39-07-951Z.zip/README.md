# MDD Ship Installation Package

Ship Name: MV TEST SHIP
Ship Code: TEST001
Company: Test Maritime

## Installation Instructions
1. Run install.bat as Administrator
2. Follow the on-screen instructions
3. Launch MDD Ship Viewer from desktop shortcut

## System Requirements
- Windows 10 or later
- 4GB RAM minimum
- 1GB free disk space
- Internet connection for document updates

## Support
Contact your company's IT administrator for support.
